import sys
import mysql.connector
from todo_db import task
from PyQt5 import QtWidgets, QtGui
from mydesign import Ui_MainWindow

class main_window(QtWidgets.QMainWindow):

    def __init__(self):
        super(main_window, self).__init__()
        self.setWindowIcon(QtGui.QIcon("todo_icon.ico"))
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.pushButton_save.setStyleSheet("background-color: rgb(0,128,0); color: white;")
        self.ui.pushButton_delete.setStyleSheet("background-color: rgb(255,0,0); color: white;")
        self.edit_PushButton_default()
        self.enable_or_disable_save_PushButton()
        """ this disables the save button until the user clicks to type a new task 
            and disables the save button anytime the text input is blank"""
        self.ui.plainTextEdit.textChanged.connect(self.enable_or_disable_save_PushButton)
        self.ui.pushButton_edit.clicked.connect(self.change_editButton_text)
        self.ui.pushButton_save.clicked.connect(self.add_task_to_db)

    # this function makes the edit button blue by default
    def edit_PushButton_default(self):
        self.ui.pushButton_edit.setText("Edit")
        self.ui.pushButton_edit.setStyleSheet("background-color: #0066CC; color: white;")

    def change_editButton_text(self):
        if self.ui.pushButton_edit.text() == "Edit":
            self.ui.pushButton_edit.setText("Update")
            self.ui.pushButton_edit.setStyleSheet("background-color: rgb(255,69,0); color: white;")   
        else:
            self.edit_PushButton_default()

    """ this function checks whether the textEdit for new tasks is empty
        returns true if empty and false otherwise."""

    def isEmpty_new_task_TextEdit(self):
        self.content = self.ui.plainTextEdit.toPlainText()
        if self.content == "":
            return True
        else:
            return False

    def enable_or_disable_save_PushButton(self):
        if self.isEmpty_new_task_TextEdit():
            self.ui.pushButton_save.setEnabled(False)
        else:
            self.ui.pushButton_save.setEnabled(True)


    def add_task_to_db(self):
        # self.start = str(self.ui.start_dateTimeEdit.dateTime) # work on inserting the date directly from the gui to the database
        self.START = "13/12/18"
        # dt_string = dt.toString(self.StartTime.displayFormat())
        self.END = "15/12/18"
        self.T_DESCRIPTION = self.ui.plainTextEdit.toPlainText()
        self.new_task = task(self.START, self.END, self.T_DESCRIPTION) #inserts a new task into the task database
        self.ui.plainTextEdit.clear() # clears the text input after the user clicks the save button



app = QtWidgets.QApplication([])
application = main_window()
application.show()
sys.exit(app.exec())